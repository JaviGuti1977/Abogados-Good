const puppeteer = require('puppeteer-core');

process.on('unhandledRejection', (reason) => {
    console.error('🔴 Unhandled Rejection:', reason);
    process.exit(1);
});
process.on('uncaughtException', (err) => {
    console.error('🔴 Uncaught Exception:', err);
    process.exit(1);
});

(async () => {
    try {
        console.log("🚀 Scraper iniciado...");
        console.log("Node version:", process.version);

        const browser = await puppeteer.launch({
            headless: true,
            executablePath: '/usr/bin/chromium-browser',
            args: ['--no-sandbox', '--disable-setuid-sandbox']
        });
        console.log("✅ Navegador lanzado.");

        const page = await browser.newPage();
        await page.goto('https://www.abogacia.es/servicios-abogacia/censo-de-letrados/', {
            waitUntil: 'domcontentloaded',
            timeout: 60000
        });
        console.log("✅ Página cargada.");

        await page.waitForSelector('iframe', { timeout: 30000 });
        const iframeElement = await page.$('iframe');
        if (!iframeElement) throw new Error("❌ No se encontró el iframe en la página");

        const frame = await iframeElement.contentFrame();
        if (!frame) throw new Error("❌ No se pudo acceder al contenido del iframe");

        const frameUrl = frame.url();
        console.log("🌐 URL del iframe:", frameUrl);

        await frame.waitForSelector('#desplegableColegio', { timeout: 15000 });
        console.log("✅ Selector de colegio encontrado dentro del iframe");

        await frame.select('#desplegableColegio', 'A CORUÑA');
        console.log("✅ Colegio seleccionado: A CORUÑA");

        await frame.click('#btnBuscar');
        console.log("✅ Botón Buscar pulsado.");
        await frame.waitForSelector('table.grid tbody tr', { timeout: 30000 });
        console.log("✅ Resultados cargados.");

        const rows = await frame.$$('table.grid tbody tr');
        console.log("✅ Número de filas encontradas:", rows.length);

        const results = [];
        let index = 0;
        for (const row of rows) {
            index++;
            console.log(`Procesando fila ${index}...`);
            await row.click();
            await frame.waitForSelector('table.grid ~ table', { timeout: 30000 });
            console.log(`Fila ${index} detalle cargado.`);

            const data = await frame.evaluate(() => {
                const getText = (label) => {
                    const tds = Array.from(document.querySelectorAll('td'));
                    const el = tds.find(td => td.innerText.includes(label));
                    return el ? el.innerText.replace(label, '').trim() : null;
                };
                return {
                    nombre: getText('Nombre:'),
                    numeroColegiado: getText('N. Colegiado:'),
                    colegio: getText('Colegio:'),
                    ejerciente: getText('Ejerciente:'),
                    residente: getText('Residente:'),
                    direccion: getText('Dirección Profesional:'),
                    telefono: getText('Teléfono:')
                };
            });
            console.log(`✅ Datos extraídos fila ${index}:`, data);
            results.push(data);

            console.log(`Volviendo a la lista desde fila ${index}...`);
            await frame.click('#btnVolver');
            await frame.waitForSelector('table.grid tbody tr', { timeout: 30000 });
            console.log(`Volvió a la lista tras fila ${index}.`);
        }

        console.log("🎯 Extracción finalizada. Total registros:", results.length);
        await browser.close();
        process.exit(0);
    } catch (err) {
        console.error("❌ Error capturado en main.js:", err);
        process.exit(1);
    }
})();