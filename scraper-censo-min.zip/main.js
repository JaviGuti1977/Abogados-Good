const puppeteer = require('puppeteer-core');

(async () => {
    try {
        console.log("🚀 Actor iniciado");

        const browser = await puppeteer.launch({
            headless: true,
            executablePath: '/usr/bin/chromium-browser',
            args: ['--no-sandbox', '--disable-setuid-sandbox']
        });

        console.log("✅ Navegador lanzado");

        const page = await browser.newPage();
        await page.goto('https://example.com', { waitUntil: 'domcontentloaded' });
        console.log("✅ Página cargada");

        const title = await page.title();
        console.log("🎯 Título de la página:", title);

        await browser.close();
        console.log("✅ Navegador cerrado");
    } catch (err) {
        console.error("❌ Error:", err);
        process.exit(1);
    }
})();