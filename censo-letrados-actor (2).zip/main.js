const puppeteer = require('puppeteer-core');

process.on('unhandledRejection', (reason) => {
    console.error('🔴 Unhandled Rejection:', reason);
    process.exit(1);
});
process.on('uncaughtException', (err) => {
    console.error('🔴 Uncaught Exception:', err);
    process.exit(1);
});

(async () => {
    try {
        console.log("🚀 Scraper iniciado...");
        console.log("Node version:", process.version);

        const browser = await puppeteer.launch({
            headless: true,
            executablePath: '/usr/bin/chromium-browser',
            args: ['--no-sandbox', '--disable-setuid-sandbox']
        });
        console.log("✅ Navegador lanzado.");

        const page = await browser.newPage();
        await page.goto('https://www.abogacia.es/servicios-abogacia/censo-de-letrados/', {
            waitUntil: 'domcontentloaded',
            timeout: 60000
        });
        console.log("✅ Página cargada.");

        await page.waitForSelector('iframe', { timeout: 30000 });
        const iframeElement = await page.$('iframe');
        const frame = await iframeElement.contentFrame();
        if (!frame) throw new Error("❌ No se pudo acceder al iframe");
        console.log("✅ Acceso al iframe confirmado.");

        await frame.waitForSelector('#desplegableColegio');
        await frame.select('#desplegableColegio', 'A CORUÑA');
        await frame.click('#btnBuscar');
        console.log("🔍 Búsqueda iniciada...");

        await frame.waitForSelector('table.grid tbody tr');
        const rows = await frame.$$('table.grid tbody tr');
        console.log(`🔎 Se encontraron ${rows.length} filas.`);

        const results = [];
        for (const [index, row] of rows.entries()) {
            console.log(`➡️ Procesando fila ${index + 1}...`);
            await row.click();
            await frame.waitForSelector('table.grid ~ table', { timeout: 30000 });

            const data = await frame.evaluate(() => {
                const getText = (label) => {
                    const tds = Array.from(document.querySelectorAll('td'));
                    const el = tds.find(td => td.innerText.includes(label));
                    return el ? el.innerText.replace(label, '').trim() : null;
                };
                return {
                    nombre: getText('Nombre:'),
                    numeroColegiado: getText('N. Colegiado:'),
                    colegio: getText('Colegio:'),
                    ejerciente: getText('Ejerciente:'),
                    residente: getText('Residente:'),
                    direccion: getText('Dirección Profesional:'),
                    telefono: getText('Teléfono:')
                };
            });
            results.push(data);
            console.log(`✅ Datos fila ${index + 1}:`, data);

            await frame.click('#btnVolver');
            await frame.waitForSelector('table.grid tbody tr');
        }

        console.log(`🎯 Extracción finalizada. Total: ${results.length} registros.`);
        await browser.close();
        process.exit(0);
    } catch (err) {
        console.error("❌ Error capturado:", err);
        process.exit(1);
    }
})();