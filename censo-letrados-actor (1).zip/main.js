const Apify = require('apify');
const puppeteer = require('puppeteer-core');

Apify.main(async () => {
    const input = await Apify.getInput();
    const url = input.url || 'https://www.abogacia.es/servicios-abogacia/censo-de-letrados/';
    const colegio = input.colegio || 'A CORUÑA';

    console.log('🚀 Iniciando scraper para:', url, 'con colegio:', colegio);

    const browser = await puppeteer.launch({
        headless: true,
        executablePath: '/usr/bin/chromium-browser',
        args: ['--no-sandbox', '--disable-setuid-sandbox'],
    });

    const page = await browser.newPage();
    await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 60000 });

    await page.waitForSelector('iframe');
    const iframeElement = await page.$('iframe');
    const frame = await iframeElement.contentFrame();
    if (!frame) throw new Error("No se pudo acceder al iframe");

    await frame.waitForSelector('#desplegableColegio');
    await frame.select('#desplegableColegio', colegio);

    await frame.click('#btnBuscar');
    await frame.waitForSelector('table.grid tbody tr');

    const rows = await frame.$$('table.grid tbody tr');
    const results = [];

    for (let i = 0; i < rows.length; i++) {
        await rows[i].click();
        await frame.waitForSelector('table.grid ~ table');

        const data = await frame.evaluate(() => {
            const getText = (label) => {
                const tds = Array.from(document.querySelectorAll('td'));
                const el = tds.find(td => td.innerText.includes(label));
                return el ? el.innerText.replace(label, '').trim() : null;
            };
            return {
                nombre: getText('Nombre:'),
                numeroColegiado: getText('N. Colegiado:'),
                colegio: getText('Colegio:'),
                ejerciente: getText('Ejerciente:'),
                residente: getText('Residente:'),
                direccion: getText('Dirección Profesional:'),
                telefono: getText('Teléfono:')
            };
        });

        results.push(data);
        await frame.click('#btnVolver');
        await frame.waitForSelector('table.grid tbody tr');
    }

    console.log('🎯 Total extraído:', results.length);
    await Apify.setValue('OUTPUT', results);
    await browser.close();
});
