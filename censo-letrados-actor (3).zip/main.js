const puppeteer = require('puppeteer-core');
const Apify = require('apify');

Apify.main(async () => {
    const input = await Apify.getInput();
    const url = input?.url || 'https://www.abogacia.es/servicios-abogacia/censo-de-letrados/';
    const colegio = input?.colegio || 'A CORUÑA';

    console.log("🚀 Scraper iniciado...");
    console.log("🌍 URL:", url);
    console.log("🏫 Colegio:", colegio);

    const browser = await puppeteer.launch({
        headless: true,
        executablePath: '/usr/bin/chromium-browser',
        args: ['--no-sandbox', '--disable-setuid-sandbox']
    });
    console.log("✅ Navegador lanzado.");

    const page = await browser.newPage();
    await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 60000 });
    console.log("✅ Página cargada.");

    await page.waitForSelector('iframe', { timeout: 30000 });
    console.log("✅ Iframe encontrado.");
    const iframeElement = await page.$('iframe');
    const frame = await iframeElement.contentFrame();
    if (!frame) throw new Error("No se pudo acceder al iframe");
    console.log("✅ Acceso al iframe confirmado.");

    await frame.waitForSelector('#desplegableColegio', { timeout: 15000 });
    console.log("✅ Selector de colegio encontrado.");
    await frame.select('#desplegableColegio', colegio);
    console.log(`✅ Colegio seleccionado: ${colegio}`);

    await frame.click('#btnBuscar');
    console.log("✅ Botón Buscar pulsado.");
    await frame.waitForSelector('table.grid tbody tr', { timeout: 30000 });
    console.log("✅ Resultados cargados.");

    const rows = await frame.$$('table.grid tbody tr');
    console.log("📄 Filas encontradas:", rows.length);

    const results = [];
    for (const row of rows) {
        await row.click();
        await frame.waitForSelector('table.grid ~ table', { timeout: 30000 });

        const data = await frame.evaluate(() => {
            const getText = (label) => {
                const tds = Array.from(document.querySelectorAll('td'));
                const el = tds.find(td => td.innerText.includes(label));
                return el ? el.innerText.replace(label, '').trim() : null;
            };
            return {
                nombre: getText('Nombre:'),
                numeroColegiado: getText('N. Colegiado:'),
                colegio: getText('Colegio:'),
                ejerciente: getText('Ejerciente:'),
                residente: getText('Residente:'),
                direccion: getText('Dirección Profesional:'),
                telefono: getText('Teléfono:')
            };
        });

        results.push(data);
        await frame.click('#btnVolver');
        await frame.waitForSelector('table.grid tbody tr', { timeout: 30000 });
    }

    console.log("🎯 Registros extraídos:", results.length);
    await Apify.setValue('OUTPUT', results);
    await browser.close();
});